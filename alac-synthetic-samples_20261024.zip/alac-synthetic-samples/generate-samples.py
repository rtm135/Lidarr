"""Generate synthetic ALAC fixtures without using any source recordings.

Requires ffmpeg on PATH. The waveform is a 1 kHz mathematical sine at FFmpeg's
low default amplitude, encoded as stereo at the requested depth/sample rate.
Each file contains 0.25 seconds of decodable audio, not just MP4 metadata.
"""
from pathlib import Path
import subprocess

OUTPUT = Path(__file__).resolve().parent / 'samples'
RATES = (44100, 48000, 88200, 96000, 176400, 192000)
OUTPUT.mkdir(exist_ok=True)
for bits, sample_format in ((16, 's16p'), (24, 's32p')):
    for rate in RATES:
        filename = OUTPUT / f'alac-{bits}-{rate}.m4a'
        subprocess.run([
            'ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-y',
            '-f', 'lavfi', '-i', f'sine=frequency=1000:sample_rate={rate}:duration=0.25',
            '-ac', '2', '-c:a', 'alac', '-sample_fmt', sample_format,
            '-map_metadata', '-1', str(filename)
        ], check=True)
print('Generated 12 synthetic ALAC fixtures.')
