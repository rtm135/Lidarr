# ALAC sample files for TagLibSharp testing

Twelve playable MP4/M4A files containing a 0.25-second, 1 kHz synthetic sine wave in stereo. No music, voices, source recordings or third-party samples were used.

- Bit depths: 16 and 24 bits.
- Sample rates: 44.1, 48, 88.2, 96, 176.4 and 192 kHz at each bit depth.
- Encoder: FFmpeg ALAC.
- License: CC0 1.0; see LICENSE.txt.

## Expected properties

`expected-properties.csv` and `.json` contain independently measured properties for every file, plus the old-reader observations and patched-reader bitrate. Bitrate is the compressed audio-stream bitrate, not whole-file size or uncompressed PCM rate. Integer-kbps readers may differ by less than 1 kbps due to truncation.

| File | Bits | Rate (Hz) | Channels | Old reader rate (Hz) | Patched bitrate (kbps) |
|:---|---:|---:|---:|---:|---:|
| alac-16-176400.m4a | 16 | 176400 | 2 | 44100 | 528 |
| alac-16-192000.m4a | 16 | 192000 | 2 | 48000 | 558 |
| alac-16-44100.m4a | 16 | 44100 | 2 | 44100 | 161 |
| alac-16-48000.m4a | 16 | 48000 | 2 | 48000 | 177 |
| alac-16-88200.m4a | 16 | 88200 | 2 | 44100 | 277 |
| alac-16-96000.m4a | 16 | 96000 | 2 | 48000 | 292 |
| alac-24-176400.m4a | 24 | 176400 | 2 | 44100 | 3355 |
| alac-24-192000.m4a | 24 | 192000 | 2 | 48000 | 3656 |
| alac-24-44100.m4a | 24 | 44100 | 2 | 44100 | 867 |
| alac-24-48000.m4a | 24 | 48000 | 2 | 48000 | 962 |
| alac-24-88200.m4a | 24 | 88200 | 2 | 44100 | 1690 |
| alac-24-96000.m4a | 24 | 96000 | 2 | 48000 | 1842 |

The installed TagLibSharp-Lidarr 2.2.0.27 reader reports BitsPerSample=0 and AudioBitrate=0 on all twelve files. Its high sample-rate readings are shown above. These observations do not assert that a newer TagLibSharp version has the same bug; that is what these samples let you check.

Relevant TagLib properties: `file.Properties.BitsPerSample`, `AudioSampleRate`, `AudioChannels` and `AudioBitrate`.

## Verification performed

All twelve files were inspected with ffprobe, decoded completely with ffmpeg, and read with both the original 2.2.0.27 reader and the patched reader. The patched reader matched every expected bit depth, rate and channel count. Its bitrate agreed with ffprobe within 1 kbps. SHA256SUMS covers all other files in this package.

## Reproduce

With Python 3 and FFmpeg available, run `python3 generate-samples.py`. The script uses only FFmpeg's mathematical sine source. Output metadata targets remain the same, but compressed bytes and bitrates can vary between FFmpeg versions.

Inspect a file with:

    ffprobe -v error -select_streams a:0 -show_entries stream=codec_name,sample_rate,channels,bits_per_raw_sample,bit_rate,duration -of json samples/alac-24-96000.m4a

Fully decode a file with:

    ffmpeg -v error -xerror -i samples/alac-24-96000.m4a -f null -

Generation/verification version:

ffmpeg version 9.0.2 Copyright (c) 2000-2026 the FFmpeg developers
